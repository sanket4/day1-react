const Contact = () => {
  return (
    <div>
      <h1>contact us is this</h1>
    </div>
  );
};

export default Contact;

# react

# bundler which is parcel

    - it makes our life easy
    - create dev build with command npx parcel index.html --> here we specifying the entry point of the app
    - local server hosting
    - HMR - Hot Module Replacement --> refreshing the content on its's own on the server
    - File Watching Algorithm --> checks for any changes
    - Caching - faster build
    - Image Optimization
    - Minification
    - Bundling
    - compressing

# food app

// header -- logo and nav items
// body -- search bar, restaurantContainer, restaurantCard
// footer -- links, copyright

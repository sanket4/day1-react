const Grocery = () => {
  return (
    <div>
      <h1>this is our Grocery Page, You can shop your daily groceries here.</h1>
    </div>
  );
};

export default Grocery;
